Dashlet sablon create
===

### License:

Distributed under the MIT license.
