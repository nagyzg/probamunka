<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_LOAD_DASHLETS'] = 'Műszerfal beállítások betöltése';
$mod_strings['LBL_SAVE_DASHLETS'] = 'Műszerfal beállítások mentése';
$mod_strings['LBL_DASHLET_SETTINGS'] = 'Műszerfal beállítások';
$mod_strings['LBL_LOAD_DASHLET_SETTINGS'] = 'Műszerfal beállítások betöltése';
$mod_strings['LBL_SAVE_DEFAULT_DASHLET_SETTINGS'] = 'Mentés publikusként';
$mod_strings['LBL_LOAD'] = 'Betöltés';
$mod_strings['LBL_SAVE'] = 'Mentés';
