<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_LOAD_DASHLETS'] = 'Load dashlets settings';
$mod_strings['LBL_SAVE_DASHLETS'] = 'Save dashlets settings';
$mod_strings['LBL_DASHLET_SETTINGS'] = 'Dashlet settings';
$mod_strings['LBL_DASHLET_PREFERENCES'] = 'Load default';
$mod_strings['LBL_LOAD_DASHLET_SETTINGS'] = 'Load dashlet settings';
$mod_strings['LBL_SAVE_DEFAULT_DASHLET_SETTINGS'] = 'Save default dashlet settings as';
$mod_strings['LBL_LOAD'] = 'Load';
$mod_strings['LBL_SAVE'] = 'Save';
