<?php
include('custom/metadata/dashlet_storage_metadata.php');