This package 4 module (Accounts,Contacts,Leads,Opportunities) add Latest Activity field

===

### License:

Distributed under the MIT license.


Create package zip

1.Install composer https://getcomposer.org/
2.Download Dependency 
3.zip in all directory and files