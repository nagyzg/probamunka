<?php

$dictionary['Contact']['fields']['activities_modification_date'] = array(
    'name'=>'activities_modification_date',
    'vname'=>'LBL_ACTIVITIES_MODIFICATION_DATE',
    'type'=>'datetimecombo',     
);
