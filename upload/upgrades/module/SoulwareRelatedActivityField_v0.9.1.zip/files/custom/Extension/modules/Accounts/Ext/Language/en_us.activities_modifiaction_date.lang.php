<?php

$mod_strings['LBL_ACTIVITIES_MODIFICATION_DATE'] = "Latest Activity";
