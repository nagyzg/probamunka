<?php

$mod_strings['LBL_DUPLICATE_W_CHILDREN_LABEL'] = 'Duplicate with Tasks';
$mod_strings['LBL_DELETE_W_CHILDREN_LABEL'] = 'Delete with Tasks';

?>
