<?php

$mod_strings['LBL_DUPLICATE_W_CHILDREN_LABEL'] = 'Duplikálás feladatokkal';
$mod_strings['LBL_DELETE_W_CHILDREN_LABEL'] = 'Törlés feladatokkal';

?>
