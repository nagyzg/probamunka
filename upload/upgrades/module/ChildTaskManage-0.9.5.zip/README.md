Duplicate and Delete with child tasks plugin for SugarCRM CE Projects module
===

Adds two new buttons to projects's detailview, one for duplicate and one for delete project with all child tasks.

### License:

Distributed under the MIT license.
