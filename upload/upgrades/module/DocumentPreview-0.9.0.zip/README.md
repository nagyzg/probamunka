Adds a document preview popup to documtn list view and subpanels
===

### License:

Distributed under the MIT license.
