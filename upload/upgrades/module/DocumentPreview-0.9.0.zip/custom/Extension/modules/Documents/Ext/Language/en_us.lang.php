<?php

$mod_strings['LBL_LIST_IMAGE_TOOLTIP'] = "Preview";

?>
