Removes state from Address fields, as Hungarian addresses don't need it.
===

### License:

Distributed under the MIT license.
