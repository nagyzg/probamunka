#Number Summary For ListView

Adds an option to ListView to summarize all the number type fields for the selected records.

**Warning!** This plugin is not upgrade safe. This plugin modifies the include/MVC/View/view/view.list.php file on install, it's highly recommended to make backup before install.

The package is uninstallable and removes all the modifications from any core files it changed on install.

##License

Distributed under the MIT license.
