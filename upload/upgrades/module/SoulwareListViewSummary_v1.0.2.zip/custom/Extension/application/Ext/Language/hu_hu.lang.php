<?php

$app_strings['LBL_SUMMARY_BUTTON'] ='Számok összesitése';
