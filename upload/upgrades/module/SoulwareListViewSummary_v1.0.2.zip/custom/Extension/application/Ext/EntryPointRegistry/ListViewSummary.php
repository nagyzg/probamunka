<?php
$entry_point_registry['sum']=Array();
$entry_point_registry['sum']['file']='ListViewSummary.php';
$entry_point_registry['sum']['auth']=true;

