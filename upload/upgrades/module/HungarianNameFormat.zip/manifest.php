<?php

$manifest = array(
	'acceptable_sugar_versions' => array (
		'regex_matches' => array (
			0 => "5.0.*",
			1 => "5.1.*",
			2 => "5.2.*",
			3 => "5.5.*",
			4 => "6.4.*",
			5 => "6.5.*",
		),
	),
	'acceptable_sugar_flavors' => array (
		0 => 'CE',
	),
	'name' 				=> 'SoulwareHungarianNameFormat',
	'description' 		=> 'Switches first and last name fileds in forms.',
	'author' 			=> 'Gábor Darvas, Soulware Ltd.',
	'published_date'	=> '2014/02/25',
	'version' 			=> '0.9.0',
	'type' 				=> 'module',
	'icon' 				=> '',
	'is_uninstallable' => true,
);
$installdefs = array(
	'id'=> 'SoulwareHungarianNameFormat',
	'copy' => array(
	),
);

?>
