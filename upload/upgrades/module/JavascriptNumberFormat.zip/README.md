Format numbers real time with javascript
===

Adds realtime number formatting for currency, int and number type fields.

### License:

Distributed under the MIT license.
