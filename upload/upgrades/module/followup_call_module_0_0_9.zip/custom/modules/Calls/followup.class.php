<?php

require_once('modules/Calls/Call.php');
require_once('include/TimeDate.php');

class followup {
    
    public function createFollowupCall ($bean, $event, $arguments) {
        $GLOBALS['log']->fatal("in createFollowupCall");

        $create_followup = false; // flag: if true, fill variables 
        
        // in case of editing followup type can be disabled so as a result it is empty
        // to prevent new followup call creation in these cases we need to retrieve original row
        // to check the original value
        $act_followup_type = false;
        if ($bean->id) {
            $act_call = new Call();
            if ($act_call->retrieve($bean->id)) {
                $act_followup_type = $act_call->followup_type;
            }
        }
            
        /* 
         * note: empty $bean->followup_type prevents infinite calls creation:
         *      when new bean is saved followup_type should be empty
         *      and act_followup type should be empty as well
         */
        
        if ($bean->parent_type 
                && $bean->parent_name 
                && ($bean->status == 'Held' || $bean->status == 'Not Held' )
                && $bean->generate_followup
                && $bean->followup_type 
                && !$bean->followup_call_child_id) {
            
            switch ($bean->followup_type) {
                case 'fix_time':
                    $create_followup = true; // create followup call
                    $followup_date_start = $bean->followup_datetime;
                    break;
                case 'period':
                    $create_followup = true; // create followup call 
                    $followup_date_start = self::generatePeriodDateTime($bean->date_start, $bean->followup_period, '09:00:00');
                    break;
                /* in all the other cases do not create followup call
                case 'close':
                    break;
                default:
                    break;
                * 
                */
            }
        }
        
        if ($create_followup) {
            
            $newcall = new Call();
            
            $newcall->date_start = $followup_date_start;

            if ($bean->is_generated_followup) {
                // all followup calls will have same parent id = initiating call
                $newcall->followup_call_parent_id = $bean->followup_call_parent_id;
            }
            else {
                // we are creating the first followup call
                $newcall->followup_call_parent_id = $bean->id;
            }
            $newcall->name = $bean->followup_name;
            $newcall->followup_name = $bean->followup_name;
            //$newcall->date_entered = $bean->date_entered;
            //$newcall->date_modified = $bean->date_modified;
            //$newcall->modified_user_id = $bean->modified_user_id;
            $newcall->created_by = $bean->created_by;
            //$newcall->description = $bean->description;
            //$newcall->deleted = $bean->deleted;
            $newcall->assigned_user_id = $bean->assigned_user_id;
            // ??? $newcall->duration_hours = $bean->duration_hours;
            $newcall->duration_minutes = 15;
            //$newcall->date_start = $bean->date_start;
            // ??? $newcall->date_end = $bean->date_end;
            $newcall->direction = 'Outbound';
            $newcall->status = 'Planned';
            $newcall->parent_type = $bean->parent_type;
            $newcall->parent_id = $bean->parent_id;
            //$newcall->reminder_time = $bean->reminder_time;
            //$newcall->email_reminder_time = $bean->email_reminder_time;
            //$newcall->email_reminder_sent = $bean->email_reminder_sent;
            //$newcall->outlook_id = $bean->outlook_id;
            //$newcall->repeat_type = $bean->repeat_type;
            //$newcall->repeat_interval = $bean->repeat_interval;
            //$newcall->repeat_dow = $bean->repeat_dow;
            //$newcall->repeat_until = $bean->repeat_until;
            //$newcall->repeat_count = $bean->repeat_count;
            //$newcall->repeat_parent_id = $bean->repeat_parent_id;
            //$newcall->recurring_source = $bean->recurring_source;
            //$newcall->followup = $bean->followup;
            $newcall->generate_followup = 1; // for generated followup force generation as well
            $newcall->is_generated_followup = 1;

            // note: followup specific variables are not prefilled

            //$newcall->followup_type = $bean->followup_type;
            //$newcall->followup_period = $bean->followup_period;
            //$newcall->followup_close_reason = $bean->followup_close_reason;
            //$newcall->followup_datetime = $bean->followup_datetime;

            $newcall->save(); 
            if ($newcall->id) {
                if (!$bean->followup_call_child_id) {
                    $bean->followup_call_child_id = $newcall->id;
                    $bean->save(); // 
                }
            }
        }
        
    }

    private function generatePeriodDateTime($d, $period, $His) {
        
        global $current_user;
        $GLOBALS['log']->fatal("TimeDate::userTimezone(user) = " . TimeDate::userTimezone($current_user)); 
        
        $p = null;
        switch ($period) {
             case '1m': $p = 'P1M';
                        break;
             case '2m': $p = 'P2M';
                        break;
             case '3m': $p = 'P3M';
                        break;
             case '6m': $p = 'P6M';
                        break;
        }
        $ret = $d;
        if (!empty($d) && $p) {
            $eod = new DateTime($d);
            $eod->add(new DateInterval($p));
            // if neccessary increment the day till it is a working day
            // note: 0 = Sunday, 6 = Saturday
            while ($eod->format('w') == 0 || $eod->format('w') == 6) {
                $eod->add(new DateInterval('P1D')); // add 1 day till it is a working day
            }
            
            $ret = $eod->format('Y-m-d ' . $His); // !!!note the space after 'd'!!!
        }
        
        // Instantiate the TimeDate Class
        $timeDate = new TimeDate();

        // read the assigned user
        $u = new User();
        $u->retrieve($bean->assigned_user_id);
        // set timezone 
        $timeDate->setUser($u);
        
        // convert to GMT to have datetime displayed exactly as specified in $His 
        $ret = $timeDate->convert_to_gmt_datetime($ret); 

        return $ret;
    }
    
}