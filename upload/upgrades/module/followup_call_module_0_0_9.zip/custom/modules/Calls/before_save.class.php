<?php

require_once('modules/Calls/Call.php');

class before_save {
    
    public function update_generate_followup ($bean, $event, $arguments) {
        $GLOBALS['log']->fatal("in update_generate_followup");

        // this is a disabled checkbox caused problem workaround
        // problem: disabled checkbox will be saved with '0' value instead of '1'
        if ($_POST['old_generate_followup'] == '1') {
            $bean->generate_followup = '1';
        }
    }

    public function generate_name($bean, $event, $arguments) {
        $GLOBALS['log']->fatal("in generate_name");

        global $mod_strings, $app_list_strings;
        
        $prefix = $mod_strings['LBL_FOLLOWUP_CALL_PREFIX'];

        // for generated followup calls prepend followup call prefix
        if ($bean->is_generated_followup) {
            $prefix = $mod_strings['LBL_FOLLOWUP_CALL_PREFIX'];
            $GLOBALS['log']->fatal("prefix 1 = $prefix ");
            $separator = ' - ';
            // read the old(=present) values of the bean to determine actual prefix used
            // we need this to continue to use language specific prefix for this followup calls chain
            $oldbean = new Call();
            if ($bean->id) {
                $oldbean->retrieve($bean->id);
                $partnames = explode($separator, $oldbean->name);
                $GLOBALS['log']->fatal("partnames = " . print_r($partnames, true));
                if ($partnames[0]) {
                    $prefix = $partnames[0];
                }
            }
            $GLOBALS['log']->fatal("prefix 2 = $prefix ");
            $prefix = $prefix . $separator;
            $GLOBALS['log']->fatal("prefix 3 = $prefix ");
            // prepend only when it is not there
            if (substr($bean->name, 0, strlen($prefix)) != $prefix) {
                $bean->name = $prefix . $bean->name;
            }
        }
    }

}
