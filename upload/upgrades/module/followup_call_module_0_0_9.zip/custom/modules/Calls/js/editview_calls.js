console.log("CALLS INCLUDED");

$(document).ready(function ()
{
    
    function hidePanel(name) {
        var p1 = $('#' + name);
        p1.parent().hide();
    }

    function showPanel(name) {
        var p1 = $('#' + name);
        p1.parent().show();
    }

    function hideRow(name) {
        var p1 = $('#' + name);
        p1.parent().parent().hide();
    }

    function showRow(name) {
        var p1 = $('#' + name);
        p1.parent().parent().show();
    }

    function myAddValidate(fieldName, type, fieldLabel) {
        var id = '#' + fieldName + '_label';
        $(id).append('<span style="color: red;">*</span>');
        removeFromValidate('EditView', fieldName);
        addToValidate('EditView', fieldName, type, true, fieldLabel);
    }
    ;
    function myRemoveValidate(fieldName) {
        var id = '#' + fieldName + '_label';
        $(id).find('span').remove();
        removeFromValidate('EditView', fieldName);
    }

    function followup_logic() {
        
        var is_edit_session = false;
        var is_create_session = false;
        
        if ($("[name='record']")[0].value) {
            // if record id exists this is an edit session
            is_edit_session = true; // not used at the moment
        }
        else {
            // if record id does not exists this is a create session
            is_create_session = true;
        }
        
        var allow_followup_parameters_validation = false;
        if ($("[name='old_followup_type']")[0].value == '') {
            allow_followup_parameters_validation = true;
        }
        
        // remove validation to prevent missbehaviour due multiple addToValidate function calls 
        // later in the code we are adding validation rules again
        myRemoveValidate('followup_type');
        myRemoveValidate('followup_datetime');
        myRemoveValidate('followup_period');
        myRemoveValidate('followup_close_reason');
        myRemoveValidate('followup_name');
        
        if ($("#parent_type").val()
                && $("#parent_name").val()
                && ($("#status").val() == 'Held' || $("#status").val() == 'Not Held')
                && document.getElementById('generate_followup').checked) {

            showPanel('LBL_PANEL_FOLLOWUP');
            showRow('followup_type');
        
            if (is_create_session || allow_followup_parameters_validation) {
                // clear validate to prevent missbehaviour due multiple addToValidate function calls 
                myRemoveValidate('followup_type');
                myAddValidate('followup_type','enum', SUGAR.language.translate("Calls","LBL_FOLLOWUP_TYPE"));
            }

            var followup_type_value = $("#followup_type").val();

            if (followup_type_value == '') {
                
                hideRow('followup_datetime');
                hideRow('followup_period');
                hideRow('followup_close_reason');
                
                if (is_create_session || allow_followup_parameters_validation) {
                    myRemoveValidate('followup_datetime');
                    myRemoveValidate('followup_period');
                    myRemoveValidate('followup_close_reason');
                }
                
            }
            if (followup_type_value == 'fix_time') {
                
                showRow('followup_datetime');
                hideRow('followup_period');
                hideRow('followup_close_reason');

                if (is_create_session || allow_followup_parameters_validation) {
                    myAddValidate('followup_datetime','datetime', SUGAR.language.translate("Calls","LBL_FOLLOWUP_DATETIME"));
                    myRemoveValidate('followup_period');
                    myRemoveValidate('followup_close_reason');
                }
                
            }
            if (followup_type_value == 'period') {
                
                hideRow('followup_datetime');
                showRow('followup_period');
                hideRow('followup_close_reason');
                
                if (is_create_session || allow_followup_parameters_validation) {
                    myRemoveValidate('followup_datetime');
                    myAddValidate('followup_period','enum', SUGAR.language.translate("Calls","LBL_FOLLOWUP_PERIOD"));
                    myRemoveValidate('followup_close_reason');
                }

            }
            if (followup_type_value == 'close') {
                
                hideRow('followup_datetime');
                hideRow('followup_period');
                showRow('followup_close_reason');
                
                if (is_create_session || allow_followup_parameters_validation) {
                    myRemoveValidate('followup_datetime');
                    myRemoveValidate('followup_period');
                    myAddValidate('followup_close_reason','text',  SUGAR.language.translate("Calls","LBL_FOLLOWUP_CLOSE_REASON"));
                }
            }
            
            // followup_name related logic
            if (followup_type_value == 'fix_time' || followup_type_value == 'period') {

                showRow('followup_name');
                if (is_create_session || allow_followup_parameters_validation) {
                    myAddValidate('followup_name','varchar', SUGAR.language.translate("Calls","LBL_FOLLOWUP_NAME"));
                }
                
                updateFollowupName();
                
            }
            else {
                hideRow('followup_name');
            }

        }
        else {

            // hide followup panel
            hidePanel('LBL_PANEL_FOLLOWUP');

            // hide rows
            hideRow('followup_type');
            hideRow('followup_datetime');
            hideRow('followup_period');
            hideRow('followup_close_reason');
            hideRow('followup_name');
            
            // although during edit session many initiating fields are disabled for editing
            // followup variables should be cleared only during create session
            if (is_create_session) {
                clearFollowupVariables();
            }
        }
    }
    
    function disableFollowupFields() {
        
        var is_edit_session = false;
        var is_create_session = false;
        
        if ($("[name='record']")[0].value) {
            // if record id exists this is an edit session
            is_edit_session = true; // not used at the moment
        }
        else {
            // if record id does not exists this is a create session
            is_create_session = true;
        }
        
        // disable followup initiating fields when generated or editing a call which has followup call created 
        if ($("#is_generated_followup").val() == '1' 
                || (document.getElementById('generate_followup').checked && is_edit_session)) {
            $("#generate_followup").prop('disabled', true);
            $("#parent_type").prop('disabled', true);
            $("#parent_name").prop('disabled', true);
            $("#btn_parent_name").prop('disabled', true);
            $("#btn_clr_parent_name").prop('disabled', true);
        }
        // when status is 'Held' and 'Not Held' it can not be modified back
        if (is_edit_session 
                && document.getElementById('generate_followup').checked
                && ($("#status").val() == 'Held' || $("#status").val() == 'Not Held')) {
            // direction and status can not be modified
            $("#direction").prop('disabled', true);
            $("#status").prop('disabled', true);
        }

        // disable followup specific fields when edit session
        if (is_edit_session && $("[name='old_followup_type']")[0].value != '') {
            $("#followup_type").prop('disabled', true);
            $("#followup_datetime_date").prop('disabled', true);
            $("#followup_datetime_hours").prop('disabled', true);
            $("#followup_datetime_minutes").prop('disabled', true);
            $("#followup_period").prop('disabled', true);
            $("#followup_close_reason").prop('disabled', true);
            $("#followup_name").prop('disabled', true);
        }
    }
    
    function clearFollowupVariables() {
        $("#followup_type").val('');
        $("#followup_datetime_date").val('');
        $("#followup_datetime_hours").val('');
        $("#followup_datetime_minutes").val('');
        $("#followup_period").val('');
        $("#followup_close_reason").val('');
        $("#followup_name").val('');
    }

    function updateFollowupName() {
        var is_edit_session = false;
        var is_create_session = false;
        if ($("[name='record']")[0].value) {
            // if record id exists this is an edit session
            is_edit_session = true; // not used at the moment
        }
        else {
            // if record id does not exists this is a create session
            is_create_session = true;
        }

        // overwrite followup_name when create session and empty
        if ($('#followup_name').val() == '' && is_create_session) {
            $('#followup_name').val($('#name').val());
        }
    }

    function setParentMandatory () {
        if (document.getElementById('generate_followup').checked) {
            myAddValidate('parent_name','text',  SUGAR.language.translate("Calls","LBL_PARENT_NAME"));
        } 
        else {
            myRemoveValidate('parent_name');
        }
    }

    $("#parent_type").change(function () {
        followup_logic();
    });
    // not working, since value is changed by javasript widget
    /*
    $("#parent_name").change(function () {
        followup_logic();
    });
    */
    // instead of "parent_name.change" use "btn_parent_name.focus"
    $("#btn_parent_name").focus(function () {
        followup_logic();
    });
    // force followup_logic call in case of performed ajax search
    $("#parent_name").focusout(function () {
        followup_logic();
    });
    // force followup_logic call in case of performed ajax search
    $("#parent_name").mouseout(function () {
        followup_logic();
    });
    $("#status").change(function () {
        followup_logic();
    });
    $("#generate_followup").change(function () {
        followup_logic();
    });
    $("#followup_type").change(function () {
        followup_logic();
    });
    $("#name").change(function () {
        updateFollowupName();
    });
    $("#generate_followup").change(function () {
        setParentMandatory();
    });

    followup_logic();

    disableFollowupFields();

    setParentMandatory();
    
});