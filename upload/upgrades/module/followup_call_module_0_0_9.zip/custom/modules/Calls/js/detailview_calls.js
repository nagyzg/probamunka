/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function ()
{

    function hidePanel(name)
    {
        $('#' + name).hide();
    }
/* not used
    function showPanel(name)
    {
        $('#' + name).show();
    }
*/

    function hideRow(name)
    {
        $('#' + name).parent().parent().hide();
    }
    function hideRow(name)
    {
        $('#' + name).parent().parent().hide();
    }
/* not used
    function showRow(name)
    {
        $('#' + name).parent().parent().parent().show();
    }
*/

    function followup_logic() {
        if ($("[name='generate_followup']")[0].value || $("[name='followup_type']")[0].value || $("[name='followup_call_parent_id']")[0].value) {

            //showPanel('LBL_PANEL_FOLLOWUP');
            var followup_type_value = $("[name='followup_type']")[0].value;

            if (followup_type_value == '') {

                hideRow('followup_type');
                hideRow('followup_datetime');
                hideRow('followup_period');
                hideRow('followup_close_reason');

            }
            if (followup_type_value == 'fix_time') {

                hideRow('followup_period');
                hideRow('followup_close_reason');

            }
            if (followup_type_value == 'period') {

                hideRow('followup_datetime');
                hideRow('followup_close_reason');

            }
            if (followup_type_value == 'close') {

                hideRow('followup_datetime');
                hideRow('followup_period');

            }
            if ($("[name='is_generated_followup']")[0].value != '1') {
                if ($('#followup_call_parent_id').parent().prop('nodeName') == 'A') {
                    $('#followup_call_parent_id').parent().parent().parent().hide();
                }
                else {
                    $('#followup_call_parent_id').parent().parent().hide();
                }
            }
        }
        else {
            hidePanel('LBL_PANEL_FOLLOWUP');
        }
    }

    followup_logic();

});
