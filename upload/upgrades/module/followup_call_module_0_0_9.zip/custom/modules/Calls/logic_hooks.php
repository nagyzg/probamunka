<?php

$hook_version = 1; 
$hook_array = Array(); 

$hook_array['before_save'] = Array(); 
$hook_array['before_save'][] = Array(1, 'generate_followup checkbox save fix', 'custom/modules/Calls/before_save.class.php','before_save', 'update_generate_followup'); 
$hook_array['before_save'][] = Array(2, 'generate generated followup call name', 'custom/modules/Calls/before_save.class.php','before_save', 'generate_name'); 

$hook_array['after_save'] = Array(); 
$hook_array['after_save'][] = Array(1, 'Create new followup call', 'custom/modules/Calls/followup.class.php','followup','createFollowupCall');

$hook_array['process_record'] = Array(); 

?>