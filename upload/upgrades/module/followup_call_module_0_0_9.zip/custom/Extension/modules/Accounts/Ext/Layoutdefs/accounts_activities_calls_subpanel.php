<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$layout_defs['Accounts']['subpanel_setup']['activities']['top_buttons'] = array(
    array('widget_class' => 'SubPanelTopCreateTaskButton'),
    array('widget_class' => 'SubPanelTopScheduleMeetingButton'),
    array('widget_class' => 'SubPanelTopFullCallFormButton'),
    array('widget_class' => 'SubPanelTopComposeEmailButton'),
);
