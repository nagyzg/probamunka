<?php
$dictionary['Call']['fields']['generate_followup'] = array(
    'name' => 'generate_followup',
    'label' => 'LBL_GENERATE_FOLLOWUP',
    'type' => 'bool',
    'help' => 'Check if this call will require to generate followup call',
    'comment' => 'Check if this call will require to generate followup call',
);

$dictionary['Call']['fields']['is_generated_followup'] = array(
    'name' => 'is_generated_followup',
    'label' => 'LBL_FOLLOWUP_GENERATED',
    'type' => 'bool',
    'help' => 'Is this a call generated as followup?',
    'comment' => 'Is this a call generated as followup?',
);

$dictionary['Call']['fields']['followup_type'] = array(
    'name' => 'followup_type',
    'label' => 'LBL_FOLLOWUP_TYPE',
    'type' => 'enum',
    'options' => 'call_followup_type_list', // fix, period, close
    'help' => 'Generate/close followup based on this selection.',
    'comment' => 'Generate/close followup based on this selection.',
);

$dictionary['Call']['fields']['followup_datetime'] = array(
    'name' => 'followup_datetime',
    'label' => 'LBL_FOLLOWUP_DATETIME',
    'type' => 'datetimecombo',
    'dbType' => 'datetime',
    'help' => 'Do followup call in fixed time?',
    'comment' => 'Do followup call in fixed time?',
);

$dictionary['Call']['fields']['followup_period'] = array(
    'name' => 'followup_period',
    'label' => 'LBL_FOLLOWUP_PERIOD',
    'type' => 'enum',
    'options' => 'call_followup_period_list', // fix, period, close
    'help' => 'Followup period.',
    'comment' => 'Followup period.',
);

$dictionary['Call']['fields']['followup_close_reason'] = array(
    'name' => 'followup_close_reason',
    'label' => 'LBL_FOLLOWUP_CLOSE_REASON',
    'type' => 'text',
    'displayParams' => array (
        'rows' => 5,
        'cols' => 60,
    ),
    'help' => 'The reason why the followup workflow is closed.',
    'comment' => 'The reason why the followup workflow is closed.',
);

$dictionary['Call']['fields']['followup_name'] = array(
    'name' => 'followup_name',
    'label' => 'LBL_FOLLOWUP_NAME',
    'type' => 'varchar',
    'help' => 'Followup will be created with this name.',
    'comment' => 'Followup will be created with this name.',
);

$dictionary['Call']['fields']['followup_call_parent_id'] = array(
    'name' => 'followup_call_parent_id',
    'type' => 'id',
    'vname' => 'LBL_FOLLOWUP_CALL_PARENT_ID',
);

$dictionary['Call']['fields']['followup_call_child_id'] = array(
    'name' => 'followup_call_child_id',
    'type' => 'id',
    'vname' => 'LBL_FOLLOWUP_CALL_CHILD_ID',
);

//
// relations and links definition
//
$dictionary['Call']['relationships']['call_followup_call_1'] = array(
    'name' => 'call_followup_call_1',
    'lhs_module'=>'Calls',
    'lhs_table'=>'calls',
    'lhs_key'=>'id',
    'rhs_module'=>'Calls',
    'rhs_table'=>'calls',
    'rhs_key'=>'followup_call_parent_id',
    'relationship_type' => 'one-to-many'
);

$dictionary['Call']['fields']['followup_call_parent_1'] = array(
    'name' => 'followup_call_parent_1',
    'type' => 'link',
    'source' => 'non-db',
    'relationship' => 'call_followup_call_1',
    'vname' => 'LBL_FOLLOWUP_CALL_PARENT_1',
    'link_type' => 'one',
    'side' =>'right'
);

$dictionary['Call']['fields']['followup_call_child_1'] = array(
    'name' => 'followup_call_child_1',
    'type' => 'link',
    'source' => 'non-db',
    'relationship' => 'call_followup_call_1',
    'vname' => 'LBL_FOLLOWUP_CALL_CHILD_1',
);

$dictionary['Call']['fields']['followup_call_parent_name_1'] = array(
    'name' => 'followup_call_parent_name_1',
    'rname' => 'name',
    'type' => 'relate',
    'id_name' => 'followup_call_parent_id',
    'link' => 'followup_call_parent_1',
    'vname' => 'LBL_FOLLOWUP_CALL_PARENT_NAME_1',
    'source' => 'non-db',
    'table' => 'calls',
    'module' => 'Calls'
);

// 20160208 TP note: 
// no link fields defined since at the moment we need 'followup_call_child_id' 
// only to prevent multiple followup call creations
$dictionary['Call']['relationships']['call_followup_call_2'] = array(
    'name' => 'call_followup_call_2',
    'lhs_module'=>'Calls',
    'lhs_table'=>'calls',
    'lhs_key'=>'id',
    'rhs_module'=>'Calls',
    'rhs_table'=>'call',
    'rhs_key'=>'followup_call_child_id',
    'relationship_type' => 'one-to-many'
);
