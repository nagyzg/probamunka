<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$layout_defs['Calls']['subpanel_setup']['call_followup_call_1'] = array(
    'order'=> 1,
    'module'=>'Calls',
    'subpanel_name'=>'custom_followup',
    'sort_order'=>'asc',
    'sort_by'=>'id',
    'title_key'=>'LBL_CALL_FOLLOWUP_CALL_1_SUBPANEL',
    'get_subpanel_data' => 'followup_call_child_1',
    'top_buttons' => array (),
);