<?php
//$mod_strings['LBL_FOLLOWUP'] = 'Followup Call';

$mod_strings['LBL_GENERATE_FOLLOWUP'] = 'Hívásfolyam létrehozása';
$mod_strings['LBL_IS_GENERATED_FOLLOWUP'] = 'Generált hívás';
$mod_strings['LBL_FOLLOWUP_TYPE'] = 'Hívásfolyam típusa';
$mod_strings['LBL_FOLLOWUP_DATETIME'] = 'Következő hívás ideje';
$mod_strings['LBL_FOLLOWUP_PERIOD'] = 'Hívásfolyam periódusa';
$mod_strings['LBL_FOLLOWUP_CLOSE_REASON'] = 'Hívásfolyam lezárásának oka';
$mod_strings['LBL_FOLLOWUP_NAME'] = 'Hívás neve';

$mod_strings['LBL_CALL_FOLLOWUP_CALL_1_SUBPANEL'] = "Hívásfolyam";
$mod_strings['LBL_FOLLOWUP_CALL_PARENT_1'] = "Hívásfolyam szülő";
$mod_strings['LBL_FOLLOWUP_CALL_CHILD_1'] = "Hívásfolyam hívás";
$mod_strings['LBL_FOLLOWUP_CALL_PARENT_ID'] = "Hívásfolyam szülő ID";
$mod_strings['LBL_FOLLOWUP_CALL_PARENT_NAME_1'] = "Hívásfolyam szülő";
$mod_strings['LBL_FOLLOWUP_CALL_CHILD_ID'] = "Hívásfolyam hívás";
$mod_strings['LBL_PANEL_FOLLOWUP'] = "Hívásfolyam";
$mod_strings['LBL_FOLLOWUP_CALL_PREFIX'] = "Hívásfolyam";
$mod_strings['LBL_FOLLOWUP'] = "Hívásfolyam";
