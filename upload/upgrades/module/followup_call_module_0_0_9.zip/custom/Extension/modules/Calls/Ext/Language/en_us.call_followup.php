<?php
//$mod_strings['LBL_FOLLOWUP'] = 'Followup Call';

$mod_strings['LBL_GENERATE_FOLLOWUP'] = 'Create followup for this call';
$mod_strings['LBL_IS_GENERATED_FOLLOWUP'] = 'Generated followup call';
$mod_strings['LBL_FOLLOWUP_TYPE'] = 'Followup type';
$mod_strings['LBL_FOLLOWUP_DATETIME'] = 'Followup time';
$mod_strings['LBL_FOLLOWUP_PERIOD'] = 'Followup period';
$mod_strings['LBL_FOLLOWUP_CLOSE_REASON'] = 'Followup close reason';
$mod_strings['LBL_FOLLOWUP_NAME'] = 'Followup name';
$mod_strings['LBL_CALL_FOLLOWUP_CALL_1_SUBPANEL'] = "Followup Calls";
$mod_strings['LBL_FOLLOWUP_CALL_PARENT_1'] = "Followup Call Parent";
$mod_strings['LBL_FOLLOWUP_CALL_CHILD_1'] = "Followup Call Child";
$mod_strings['LBL_FOLLOWUP_CALL_PARENT_ID'] = "Parent Call ID";
$mod_strings['LBL_FOLLOWUP_CALL_PARENT_NAME_1'] = "Parent Call Name";
$mod_strings['LBL_FOLLOWUP_CALL_CHILD_ID'] = "Child Call ID";
$mod_strings['LBL_PANEL_FOLLOWUP'] = "Followup Call";
$mod_strings['LBL_FOLLOWUP_CALL_PREFIX'] = "Followup call";
$mod_strings['LBL_FOLLOWUP'] = "Followup";

