<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// eb_brokka_car
$app_list_strings['call_followup_period_list'] = array(
    '' => 'Please select...',
    '1m' => '1 month',
    '2m' => '2 months',
    '3m' => '3 months',
    '6m' => '6 months',
);
