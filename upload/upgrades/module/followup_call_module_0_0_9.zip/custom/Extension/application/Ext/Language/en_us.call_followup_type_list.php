<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// eb_brokka_car
$app_list_strings['call_followup_type_list'] = array(
    '' => 'Please select...',
    'fix_time' => 'Fix time',
    'period' => 'Period',
    'close' => 'Close',
);
