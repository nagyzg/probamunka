<?php

require_once 'include/generic/SugarWidgets/SugarWidgetSubPanelTopButton.php';

class SugarWidgetSubPanelTopFullCallFormButton extends SugarWidgetSubPanelTopButton {

    public function getWidgetId() {
        return parent::getWidgetId(false) . 'full_form';
    }

    public function getDisplayName() {
        global $app_strings;
        return $GLOBALS['app_strings']['LBL_CALL_FULL_FORM_BUTTON_TITLE'];
    }

    function display(&$widget_data) {
        global $currentModule;

        $return = '<form action="index.php" method="POST" name="form_subpanel_calls_full_form" id="form_subpanel_calls_full_form" style="padding-bottom: 10px;">';
        $return .= '<input type="hidden" name="module" value="Calls">';
        $return .= '<input type="hidden" name="action" value="EditView">';
        $return .= '<input type="hidden" name="return_module" value="'.$currentModule.'">';
        $return .= '<input type="hidden" name="return_action" value="DetailView">';
        $return .= '<input type="hidden" name="return_id" value="' . $this->parent_bean->id . '">';
        $return .= '<input type="hidden" name="isDuplicate" value="false">';
        $return .= '<input type="hidden" name="parent_type" value="'.$currentModule.'">';
        $return .= '<input type="hidden" name="parent_id" value="' . $this->parent_bean->id . '">';
        $return .= '<input type="hidden" name="parent_name" value="'.$this->parent_bean->name.'">';
        $return .= '<input type="submit" class="button" onclick="var _form = this.form; disableOnUnloadEditView(_form);" value="' . $this->getDisplayName() . '">';

        $return .= '</form>';
        return $return;
    }

}

?>
