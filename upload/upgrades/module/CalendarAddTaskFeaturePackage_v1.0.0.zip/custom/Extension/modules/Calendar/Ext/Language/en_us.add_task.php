<?php 
$mod_strings['LBL_CREATE_TASK'] = 'Create Task';
?>