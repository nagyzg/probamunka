<?php 
$mod_strings['LBL_CREATE_TASK'] = 'Új feladat';
?>